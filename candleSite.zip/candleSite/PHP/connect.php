<?php

try {

  $pdo = new PDO ('mysql:host=localhost; dbname=candlebd', 'root', 'root');

} catch (\PDOException $exception) {

echo "Ошибка подключения к базе данных";

}

$sql = INSERT INTO `candlebd`.`users` (`Id`, `name`, `phone_number`, `password`, `email`)
 VALUES ('4', 'Виктор', '+79023669438', '1234566', 'v54534534@gmail.com');

$query = $pdo->prepare($sql);


 ?>
